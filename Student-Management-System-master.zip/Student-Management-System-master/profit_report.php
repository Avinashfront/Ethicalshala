<?php
include 'layout/header.php';
include "page/report/profit_report.php";
include "layout/footer.php";

?>