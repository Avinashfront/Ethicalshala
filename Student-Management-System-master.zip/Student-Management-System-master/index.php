<?php

include "layout/header.php";
include "page/index/dashboard.php";
include "layout/footer.php";

?>