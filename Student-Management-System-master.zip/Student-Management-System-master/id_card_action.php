<?php

include 'layout/header_script.php';
include "page_action/id_card/edit_id_card/edit_id_card_action.php";

?>