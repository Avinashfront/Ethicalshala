

<?php 


include 'layout/header_script.php';
include 'page_action/student_profile/payment.php'; 
include 'page_action/student_profile/program.php'; 
include 'page_action/student_profile/info.php'; 

?>