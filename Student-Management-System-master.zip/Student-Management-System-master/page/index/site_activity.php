

<div class="col-md-12">
            <div class="dashboard_box">
                <div class="box_header">Live Site Activity</div>
                <div class="box_body" id="site_activity">
                     
               
                </div>
            </div>
        </div>