

<?php

$js_path="page/student/student_profile/js";
$css_path="page/student/student_profile/css";

?>
<!-- Profile Lib -->

<!-- css file -->

<link rel="stylesheet" type="text/css" href="<?php echo "$css_path" ?>/profile.css">

<!-- js script file -->
<script type="text/javascript" src="<?php echo "$js_path" ?>/profile_data.js"></script>
<script type="text/javascript" src="<?php echo "$js_path" ?>/payment.js"></script>
<script type="text/javascript" src="<?php echo "$js_path" ?>/program.js"></script>
<script type="text/javascript" src="<?php echo "$js_path" ?>/info.js"></script>
