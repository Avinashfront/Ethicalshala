var student_id;

var body="panel_profile_body";

function set_profile_data(id){
   student_id=id;
}

