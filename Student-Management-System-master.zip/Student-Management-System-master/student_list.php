<?php
 		include "layout/header.php";
 		include "page/student/student_list1.php";
 		//include "page/student/student_list.php";
 		include "layout/footer.php";
  ?>


