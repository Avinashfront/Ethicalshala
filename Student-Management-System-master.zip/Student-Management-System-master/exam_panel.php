<?php

include "layout/header.php";
include "page/exam_panel/exam_panel.php";
include "layout/footer.php";


?>