<?php
include "layout_style.php";
include "nev_bar.php";
include "side_bar.php";
?>

<div id="content" class="content"> 
	<div class="main-content" style="padding-bottom: 30px;margin-top: 15px;" >
		<?php 
  			include "bubble.php"; 
  			include "loader.php";
  			include "modal_lib.php";
 		?>

