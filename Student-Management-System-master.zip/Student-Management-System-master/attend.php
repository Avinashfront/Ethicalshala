<?php
include 'layout/header.php';
include "page/attend/attend.php";
include "layout/footer.php";

?>