<?php

include "page_action/exam_panel/exam_category_panel/include_file.php";
include "page_action/exam_panel/exam_control_panel/include_file.php";


?>