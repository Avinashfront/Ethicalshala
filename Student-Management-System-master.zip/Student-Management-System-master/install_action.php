<?php

include "page_action/install/install.php";

?>