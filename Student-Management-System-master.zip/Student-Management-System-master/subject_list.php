<?php 

include "layout/header.php";
include "page/subject/subject_list.php";
include "layout/footer.php";


?>