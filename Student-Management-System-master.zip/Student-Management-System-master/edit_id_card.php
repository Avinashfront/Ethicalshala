<?php
include "layout/header.php";
include "page/id_card/edit_id_card.php";
include "layout/footer.php";
?>