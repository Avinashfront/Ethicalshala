<?php

include 'layout/header.php';
include 'page/student/student_profile_panel.php';
include 'layout/footer.php';


?>

