<?php

include "layout/header.php";
include "page/notice/notice_list.php";
include "layout/footer.php";


?>